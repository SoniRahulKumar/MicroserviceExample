package com.yash.LoadBalancingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadBalancingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
