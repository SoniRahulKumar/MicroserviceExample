package com.yash.LoadBalancingService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoadBalancingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoadBalancingServiceApplication.class, args);
	}

}
